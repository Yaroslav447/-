﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for1
{// For1. Даны целые числа K и N (N > 0). Вывести N раз число K.
    class for1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите K");
            int k = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите N");
            int n = int.Parse(Console.ReadLine());
            if (n < 0)
            {
                Console.WriteLine("Число N меньше нуля");
            }
            else
            {
                for (int i = n; i > 0; i--)
                    Console.WriteLine(k);
            }
            Console.ReadKey();
        }
    }
}
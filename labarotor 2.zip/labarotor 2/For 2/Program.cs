﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for2
{ // Даны два целых числа A и B (A < B). Вывести в порядке возрастания все целые числа, расположенные между A и B (включая сами числа A и B), а также количество N этих чисел.
    class for2
    {
        static void Main(string[] args)
        {
            int c = 0;
            Console.WriteLine("Введите A");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите B");
            int b = int.Parse(Console.ReadLine());
            if (b < a)
            {
                Console.WriteLine("Число В больше А");
            }
            else
            {
                for (int i = a; i <= b; i++)
                {
                    c++;
                    Console.WriteLine(c);
                }

                Console.ReadLine();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for33
{//Вывести все числа Фибоначии от 1 до N. Число Фибоначчи получается суммой двух предыдущих целых чисел.
 //Дано целое число N(> 1). Последовательность чисел Фибоначчи FK(целого типа) определяется следующим образом:
 //F1 = 1,        F2 = 1,        FK = FK−2 + FK−1,    K = 3, 4, … . Вывести элементы F1, F2, …, FN.
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int F1 = 1;
            int F2 = 1;
            int F;
            for (int i = 1; i < N; i++)
            {
                F = F1 + F2;
                F1 = F2;
                F2 = F;
                Console.WriteLine(F);
            }
            Console.ReadKey();
        }
    }
}

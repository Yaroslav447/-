﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for7
{ // Даны два целых числа A и B (A < B). Найти сумму всех целых чисел от A до B включительно.
    class for7
    {

        static void Main(string[] args)
        {
            int n = 0;
            Console.WriteLine("Введите A");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите B");
            int b = int.Parse(Console.ReadLine());
            if (b < a)
            {
                Console.WriteLine("Число А больше В");
            }
            else
            {
                for (int i = a; i <= b; i++)//создаем правило при котором каждый раз увеличиваем число на 1
                    n += i;//прибавляем каждый раз следующее число
                Console.WriteLine("Сумма чисел");
                Console.WriteLine(n);
                Console.ReadLine();
            }
        }
    }
}
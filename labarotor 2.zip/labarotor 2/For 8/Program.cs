﻿using System;

namespace for4
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int n = 1;
            // Даны два целых числа A и B (A < B). Найти произведение всех целых чисел от A до B включительно.
            Console.WriteLine("Введите число A");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите число В");
            int b = int.Parse(Console.ReadLine());
            for (int i = a; i <= b; i++)
                n *= i;
            Console.WriteLine(n);

            Console.ReadLine();

        }
    }
}


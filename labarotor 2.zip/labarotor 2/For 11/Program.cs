﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for6
{
    //Дано целое число N (> 0). Найти сумму N2 + (N + 1)2 + (N + 2)2 + … + (2·N)2
    class Program
    {
        static void Main(string[] args)
        {
            double f = 0;
            int c = 1;
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i <= n; i++)
            {
                f += Math.Pow(n + i, 2);
            }
            Console.WriteLine(f);
            Console.ReadLine();
        }
    }
}

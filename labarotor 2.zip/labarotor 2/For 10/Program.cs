﻿using System;

namespace ConsoleApplication1
{
    internal class Program
    {//Дано целое число N (> 0). Найти сумму 1 + 1/2 + 1/3 + … + 1/N
        public static void Main(string[] args)
        {
            double x = 0;
            int n = int.Parse(Console.ReadLine());
            for (int c = 1; n >= c; c++)
            {
                x += 1 / (double)c;

            }
            Console.WriteLine(x);
            Console.ReadLine();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for7
{//Дано вещественное число A и целое число N (> 0). Найти A в степени N:
 //A^N = A·A· … ·A
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число N (показатель степени)");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите число A (возводимое в степнь)");
            int a = int.Parse(Console.ReadLine());
            int c = 1;
            for (int i = 1; i <= n; i++)
            {
                c *= a;
            }
            Console.WriteLine(c);
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for36
{//Даны целые положительные числа N и K. Найти сумму 1K + 2K + … + NK.
 //Чтобы избежать целочисленного переполнения, вычислять слагаемые этой суммы с помощью вещественной переменной и выводить результат как вещественное число.
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число N");
            int N = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите число K");
            int K = int.Parse(Console.ReadLine());
            for (int i = 1; i <= N; i++)
            {
                Console.WriteLine(Math.Pow(i, K));
            }
            Console.ReadKey();
        }
    }
}
